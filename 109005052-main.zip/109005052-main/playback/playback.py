# Take in input
s = input('Enter input: ')

# Replace spaces with ...
s = s.replace(' ', '...')

# Print result
print(s)