# Take in string input
string = input('Say something: ')

# Make string lowercase and print result
print(string.lower())