# Main function
def main():
    # Take in input, call convert, print resulting string
    s = input('Enter input: ')
    s = convert(s)
    print(s)

# Convert function
def convert(c):
    # Use replace() function to replace ':)' and ':('
    c = c.replace(':)','🙂')
    c = c.replace(':(','🙁')
    return c;

main()
