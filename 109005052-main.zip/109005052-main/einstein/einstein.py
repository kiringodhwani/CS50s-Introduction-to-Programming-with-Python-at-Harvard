# Take in mass input
m = int(input('Enter a mass value as an integer: '))

c = 300000000

# Perform calculation
E = m*(c**2)

# Print result
print(E)
